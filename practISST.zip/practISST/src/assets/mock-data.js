/*nomenclatura:
id_ley (1=d'Hondt, 2=Saint-Leguë)
id(0=Madrid, 1=Sevilla, 2=Valladolid)
id_ano (5=2019, 4=2016, 3=2015, 2=2011, 1=2007, 0=2003)
votos= (PP, PSOE, Ciu, Podemos, Otros)
escaños=(PP, PSOE, Ciu, Podemos, Otros)
*/
export const resultados =[
	[
		{
		"id": 0,
		"PP":[1300000, 15],
		"PSOE":[674000, 7],
		"Podemos":[700000, 8],
		"CiU":[600000, 6],
		"color":"blue"
		},
		{
		"id": 1,
		"PP":[300000, 4],
		"PSOE":[350000, 4],
		"Podemos":[200000, 3],
		"CiU":[130000, 1],
		"color":"red"
		},
		{
		"id": 2,
		"PP":[130000, 2],
		"PSOE":[70000, 1],
		"Podemos":[50000, 1],
		"CiU":[50000, 1],
		"color":"blue"
		}
	],
	[
		{
		"id": 0,
		"PP":[1100000, 15],
		"PSOE":[574000, 7],
		"Podemos":[700000, 8],
		"CiU":[600000, 6],
		"color":"blue"
		},
		{
		"id": 1,
		"PP":[300000, 4],
		"PSOE":[350000, 4],
		"Podemos":[200000, 3],
		"CiU":[130000, 1],
		"color":"red"
		},
		{
		"id": 2,
		"PP":[130000, 2],
		"PSOE":[70000, 1],
		"Podemos":[50000, 1],
		"CiU":[50000, 1],
		"color":"blue"
		}
	],	[
		{
		"id": 0,
		"PP":[1300000, 15],
		"PSOE":[674000, 7],
		"Podemos":[700000, 8],
		"CiU":[600000, 6],
		"color":"blue"
		},
		{
		"id": 1,
		"PP":[300000, 4],
		"PSOE":[350000, 4],
		"Podemos":[200000, 3],
		"CiU":[130000, 1],
		"color":"red"
		},
		{
		"id": 2,
		"PP":[130000, 2],
		"PSOE":[70000, 1],
		"Podemos":[50000, 1],
		"CiU":[50000, 1],
		"color":"blue"
		}
	],	[
		{
		"id": 0,
		"PP":[1300000, 15],
		"PSOE":[674000, 7],
		"Podemos":[700000, 8],
		"CiU":[600000, 6],
		"color":"blue"
		},
		{
		"id": 1,
		"PP":[300000, 4],
		"PSOE":[350000, 4],
		"Podemos":[200000, 3],
		"CiU":[130000, 1],
		"color":"red"
		},
		{
		"id": 2,
		"PP":[130000, 2],
		"PSOE":[70000, 1],
		"Podemos":[50000, 1],
		"CiU":[50000, 1],
		"color":"blue"
		}
	]
];


